(function(){
  // Utilities
  const qs = (s, el=document) => el.querySelector(s);
  const qsa = (s, el=document) => Array.from(el.querySelectorAll(s));

  /*  REFRESH LOGO */
  const refreshBtns = qsa('.refresh-logo');
  refreshBtns.forEach(btn => btn.addEventListener('click', () => location.reload()));

  /*  CART STORAGE */
  const CART_KEY = 'hw_cart';
  const getCart = ()=> JSON.parse(localStorage.getItem(CART_KEY) || '[]');
  const saveCart = (c)=> localStorage.setItem(CART_KEY, JSON.stringify(c));
  const updateCartCount = ()=>{
    const count = getCart().reduce((a,i)=>a+i.qty,0);
    document.querySelectorAll('#cart-count, #cart-count-2, #cart-count-checkout, #cart-count-ty, #cart-count-ty-2').forEach(el=>{
      if(el) el.textContent = count;
    });
  };
  updateCartCount();

  /* CART DRAWER UI (open/close & render) */
  function openCart(drawerId){
    const drawer = document.getElementById(drawerId);
    if(!drawer) return;
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden','false');
    renderCartDrawer(drawer);
  }
  function closeCart(drawerId){
    const drawer = document.getElementById(drawerId);
    if(!drawer) return;
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden','true');
  }

  function renderCartDrawer(drawerElement){
    const cart = getCart();
    const container = drawerElement.querySelector('.cart-items');
    const totalEl = drawerElement.querySelector('.cart-total span') || drawerElement.querySelector('#cart-total') || null;
    container.innerHTML = '';
    let total = 0;
    if(cart.length === 0){
      container.innerHTML = '<p style="opacity:0.8">Your cart is empty.</p>';
    } else {
      cart.forEach((item, idx)=>{
        const div = document.createElement('div');
        div.className = 'cart-item';
        div.innerHTML = `
          <img src="${item.image}" alt="${item.name}">
          <div style="flex:1">
            <div style="font-weight:600">${item.name}</div>
            <div style="opacity:.9">Size: ${item.size}</div>
            <div style="color:var(--accent);font-weight:700">R${item.price} × ${item.qty}</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px">
            <button class="small remove-btn" data-idx="${idx}">Remove</button>
          </div>
        `;
        container.appendChild(div);
        total += item.price * item.qty;
      });
    }
    if(totalEl) totalEl.textContent = total.toFixed(2);

    // wire up remove buttons
    qsa('.remove-btn', container).forEach(btn=>{
      btn.addEventListener('click', (e)=>{
        const idx = Number(btn.dataset.idx);
        const c = getCart();
        c.splice(idx,1);
        saveCart(c);
        renderCartDrawer(drawerElement);
        updateCartCount();
      });
    });
  }

  // open cart buttons (across pages)
  qsa('#openCartBtn, #openCartBtn2, #openCartBtnCheckout, #openCartBtnTY').forEach(btn=>{
    btn && btn.addEventListener('click', ()=>{
      // choose a drawer available on page
      const candidate = document.querySelector('.cart-drawer');
      if(candidate) openCart(candidate.id);
    });
  });

  // close drawer buttons
  qsa('#closeCartBtn, #closeCartBtnShop, #closeCartBtnCheckout, #closeCartBtnTY').forEach(btn=>{
    btn && btn.addEventListener('click', ()=>{
      const drawer = btn.closest('.cart-drawer');
      drawer && closeCart(drawer.id);
    });
  });

  /*  PRODUCTS: ADD TO CART  */
  function attachAddToCart(root=document){
    qsa('.product-card', root).forEach(card=>{
      const addBtn = qs('.add-btn', card);
      const img = qs('.product-media img', card)?.getAttribute('src') || '';
      const name = qs('.product-info h3', card)?.textContent?.trim() || 'Product';
      const priceText = qs('.price', card)?.textContent || 'R0';
      const price = parseFloat(priceText.replace(/[^0-9\.]/g,'')) || 0;
      addBtn && addBtn.addEventListener('click', ()=>{
        const sizeSelect = qs('.size-choose', card);
        const size = sizeSelect ? sizeSelect.value : 'One Size';
        const cart = getCart();
        // add or increase qty if same product+size
        const existing = cart.find(it => it.name === name && it.size === size);
        if(existing) existing.qty == 1;
        else cart.push({ name, price, size, qty: 1, image: img });
        saveCart(cart);
        updateCartCount();
        // open drawer for feedback
        const drawer = document.querySelector('.cart-drawer');
        if(drawer) openCart(drawer.id);
      });
    });
  }
  attachAddToCart();

  /* FILTERS & SORT  */
  const categoryFilter = qs('#categoryFilter');
  const sizeFilter = qs('#sizeFilter');
  const sortFilter = qs('#sortFilter');
  const productsGrid = qs('#productsGrid');

  function applyFilters(){
    if(!productsGrid) return;
    const category = categoryFilter ? categoryFilter.value : 'all';
    const size = sizeFilter ? sizeFilter.value : 'all';
    const sort = sortFilter ? sortFilter.value : 'default';

    let cards = qsa('.product-card', productsGrid);
    cards.forEach(card=>{
      const cat = card.dataset.category || '';
      const sizes = (card.dataset.sizes || '').split(',').map(s=>s.trim().toUpperCase());
      const showCat = (category === 'all') || (cat === category);
      const showSize = (size === 'all') || (sizes.includes(size.toUpperCase()));
      card.style.display = (showCat && showSize) ? '' : 'none';
    });

    // sorting by price if requested (simple DOM reorder)
    if(sort !== 'default'){
      const visible = qsa('.product-card', productsGrid).filter(c=>c.style.display !== 'none');
      const parent = productsGrid;
      const mapped = visible.map(card=>{
        const p = parseFloat((qs('.price',card)?.textContent || '').replace(/[^0-9\.]/g,''))||0;
        return { card, price: p };
      });
      if(sort === 'price-asc') mapped.sort((a,b)=>a.price-b.price);
      if(sort === 'price-desc') mapped.sort((a,b)=>b.price-a.price);
      mapped.forEach(m=> parent.appendChild(m.card));
    }
  }

  if(categoryFilter) categoryFilter.addEventListener('change', applyFilters);
  if(sizeFilter) sizeFilter.addEventListener('change', applyFilters);
  if(sortFilter) sortFilter.addEventListener('change', applyFilters);

  /* HOVER SPOTLIGHT: change hero background to hovered product image */
  const hero = qs('#hero');
  function setupHoverSpotlight(){
    const cards = qsa('.product-card');
    cards.forEach(card=>{
      card.addEventListener('mouseenter', ()=>{
        const img = card.dataset.image || qs('.product-media img', card)?.src || '';
        if(img && hero){
          hero.style.transition = 'background-image .45s ease, opacity .35s';
          hero.style.backgroundImage = `linear-gradient(180deg, rgba(0,0,0,0.6), rgba(0,0,0,0.2)), url('${img}')`;
          hero.style.filter = 'contrast(1.05)';
        }
      });
      card.addEventListener('mouseleave', ()=>{
        // restore default hero bg (hero-bg.jpg)
        if(hero){
          hero.style.backgroundImage = `linear-gradient(180deg, rgba(0,0,0,0.6), rgba(0,0,0,0.2)), url('hero-bg.jpg')`;
          hero.style.filter = 'none';
        }
      });
    });
  }
  setupHoverSpotlight();

  /* Checkout page: render order summary & handle form submit  */
  function setupCheckoutPage(){
    const summaryEl = qs('#checkoutItems');
    const totalEl = qs('#checkoutTotal');
    const form = qs('#checkoutForm');
    if(!summaryEl) return;
    const cart = getCart();
    let total = 0;
    if(cart.length === 0){
      summaryEl.innerHTML = '<p>Your cart is empty. Go to shop to add items.</p>';
    } else {
      summaryEl.innerHTML = '';
      cart.forEach(it=>{
        const d = document.createElement('div');
        d.style.marginBottom = '8px';
        d.innerHTML = `<strong>${it.name}</strong> • Size: ${it.size} • R${it.price} × ${it.qty}`;
        summaryEl.appendChild(d);
        total += it.price * it.qty;
      });
    }
    if(totalEl) totalEl.textContent = total.toFixed(2);

    if(form){
      form.addEventListener('submit', (e)=>{
        e.preventDefault();
        // simple validation
        const fullname = qs('#fullname', form).value.trim();
        const email = qs('#email', form).value.trim();
        if(!fullname || !email){
          alert('Please fill your name and email.');
          return;
        }
        // mock success: store order summary and redirect to thank you
        localStorage.removeItem(CART_KEY);
        updateCartCount();
        alert(`Thank you ${fullname}! Your order of R${total.toFixed(2)} has been placed.`);
        location.href = 'thankyou.html';
      });
    }
  }
  // run on DOMContentLoaded for checkout page
  document.addEventListener('DOMContentLoaded', ()=>{
    setupCheckoutPage();
    // attach add-to-cart again in case shop page loaded content dynamically
    attachAddToCart();
    updateCartCount();
  });

document.querySelectorAll('.colour-select').forEach(sel=>{
  sel.addEventListener('change', e=>{
    const option = sel.options[sel.selectedIndex];
    const product = sel.closest('.product-card');
    const front = product.querySelector('.front');
    const back = product.querySelector('.back');

    front.src = option.dataset.front;
    back.src = option.dataset.back;

  })
});
})();